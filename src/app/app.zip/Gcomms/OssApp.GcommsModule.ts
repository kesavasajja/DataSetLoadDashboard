import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import {FormsModule} from "@angular/forms"
import {RouterModule} from "@angular/router"
import { GcommsComponent } from './Gcomms.Component';
import { GcommsRoutes } from '../Routing/OssApp.GcommsRouting';
import { GcommsService } from '../Services/Gcomms.service';
import {HttpClientModule} from "@angular/common/http";
@NgModule({
  declarations: [
    GcommsComponent
  ],
  imports: [
    RouterModule.forChild(GcommsRoutes),
    CommonModule,FormsModule,HttpClientModule
  ],
  providers: [GcommsService],
  bootstrap: [GcommsComponent]
})
export class GcommsModule { }
