import { Component, OnInit } from '@angular/core';
import { GcommsService } from '../Services/Gcomms.service';
@Component({
  selector: 'OssApp-Gcomms',
  templateUrl: './Gcomms.component.html',
  styleUrls: ['./Gcomms.Component.css']
})
export class GcommsComponent implements OnInit {
  Gcommsdata:Array<any>=[];
  Basedata:Array<any>=[];
  constructor(private _gcommsservice: GcommsService) { }

  ngOnInit() {

    this._gcommsservice.sendGetRequest().subscribe((data: any) =>{
      console.log(data);
      this.Basedata=data;

      this.Gcommsdata=this.Basedata.filter(item=> item['Where_Used'] === 'Gcomms' );
    })

  }

}
