import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import {FormsModule} from "@angular/forms"
import {RouterModule} from "@angular/router"
import { NeXToolComponent } from './NeXTool.Component';
import { NeXToolRoutes } from '../Routing/OssApp.NeXToolRouting';
import { NeXToolService } from '../Services/NeXTool.service';
import {HttpClientModule} from "@angular/common/http";
@NgModule({
  declarations: [
    NeXToolComponent
  ],
  imports: [
    RouterModule.forChild(NeXToolRoutes),
    CommonModule,FormsModule,HttpClientModule
  ],
  providers: [NeXToolService],
  bootstrap: [NeXToolComponent]
})
export class NeXToolModule { }
