import { Component, OnInit } from '@angular/core';
import { NeXToolService } from '../Services/NeXTool.service';
@Component({
  selector: 'OssApp-NeXTool',
  templateUrl: './NeXTool.component.html',
  styleUrls: ['./NeXTool.Component.css']
})
export class NeXToolComponent implements OnInit {
  Nextooldata:Array<any>=[];
  Basedata:Array<any>=[];
  constructor(private _nextoolservice: NeXToolService) { }

  ngOnInit() {

    this._nextoolservice.sendGetRequest().subscribe((data: any) =>{
      console.log(data);
      this.Basedata=data;

      this.Nextooldata=this.Basedata.filter(item=> item['Where_Used'] === 'NexTool' );
    })

  }

}
