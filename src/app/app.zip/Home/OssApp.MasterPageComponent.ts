import { Component } from '@angular/core';
@Component({
  selector: 'OssApp-MasterView',
  templateUrl: './OssApp.MasterPageView.html'
})
export  class MasterPageComponent {

}
