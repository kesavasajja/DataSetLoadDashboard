import { Component, OnInit } from '@angular/core';
import { ChartOptions, ChartType, ChartDataset } from 'chart.js';
 import { Label } from 'ng2-charts';

@Component({
  selector: 'OssApp-home',
  templateUrl: './Home.component.html',
  styleUrls: ['./Home.component.css']
})
export class HomeComponent implements OnInit {


  barChartOptions: ChartOptions = {
    responsive: true,
  };
  barChartLabels: Label[] = ['Apple', 'Banana', 'Kiwifruit', 'Blueberry', 'Orange', 'Grapes'];
  barChartType: ChartType = 'bar';
  barChartLegend = true;
  barChartPlugins = [];
  barChartData: ChartDataset[] = [
    { data: [45, 37, 60, 70, 46, 33], label: 'Best Fruits' }
  ];



  // constructor(private _gcommsservice: GcommsService) { }


  ngOnInit() {
//     type EChartsOption = echarts.EChartsOption;

// let chartDom = document.getElementById('container')!;
// let myChart = echarts.init(chartDom);
// let option: EChartsOption | undefined;
// option && myChart.setOption(option);
// myChart.showLoading();



//     this._gcommsservice.GetTreeData().subscribe((data: any) =>{
//       myChart.hideLoading();

//     //   data[0].children.forEach(function (
//     //     datum: { collapsed: boolean; },
//     //     index: number
//     //   ) {
//     //     (index % 2 === 0 || index % 1 === 0) && (datum.collapsed = true);

//     //   },
//     //  );

//       myChart.setOption(
//         (option = {
//           tooltip: {
//             trigger: 'item',
//             triggerOn: 'mousemove'
//           },
//           series: [
//             {
//               type: 'tree',

//               data: [data[0]],

//               top: '1%',
//               left: '7%',
//               bottom: '1%',
//               right: '20%',

//               symbolSize: 7,

//               label: {
//                 position: 'left',
//                 verticalAlign: 'middle',
//                 align: 'right',
//                 fontSize: 15
//               },

//               leaves: {
//                 label: {
//                   position: 'right',
//                   verticalAlign: 'middle',
//                   align: 'left'
//                 }
//               },



//               emphasis: {
//                 focus: 'descendant'
//               },

//               expandAndCollapse: true,
//               animationDuration: 750,
//               animationDurationUpdate: 950
//             }
//           ]
//         })
//       );
//     })
  }



}
