import { NeXToolComponent } from '../NeXTool/NeXTool.Component';

export const NeXToolRoutes = [
    { path: 'NeXTool', component: NeXToolComponent },

];
