
import { GcommsComponent } from '../Gcomms/Gcomms.Component';

export const GcommsRoutes = [
    { path: 'Gcomms', component: GcommsComponent },



];
