import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class GcommsService {

}
