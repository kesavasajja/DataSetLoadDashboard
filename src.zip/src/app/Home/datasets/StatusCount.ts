export class StatusCount{
  status_ID:String ='';

  total:number=0;

}
