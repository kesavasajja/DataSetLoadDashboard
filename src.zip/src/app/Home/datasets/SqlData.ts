export class SqlData{
  used_by:String ='';
  month: number=0;
  count:number=0;

}
