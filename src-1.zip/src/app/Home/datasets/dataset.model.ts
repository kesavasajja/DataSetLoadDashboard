export class DbName{
  dataset_id: number = 0;
  dataset_name:string ='';
  age_of_data: string ='';
  frequency_Internally: string='';
  status:string='';
  source: string='';
  delivery_method: string='';
  delivery_date: string='';
  frequency_from_OS: string='';
  next_Update: string='';
  used_by: string='';
  supply_format: string=''
}
