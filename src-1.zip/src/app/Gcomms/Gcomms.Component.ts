import { Component, OnInit } from '@angular/core';
import { DbName } from '../Home/datasets/dataset.model';
import { GcommsService } from '../Services/Gcomms.service';
import { DatasetService } from 'src/app/Services/dataset.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'OssApp-Gcomms',
  templateUrl: './Gcomms.component.html',
  styleUrls: ['./Gcomms.Component.css']
})
export class GcommsComponent implements OnInit {
  searchText:any;
  form : FormGroup;
  p:number = 1;
 pageSize: number = 5;
  _datasets: DbName[]= [];
  dataset: DbName = {
    dataset_id:0,
    dataset_name: '',
    age_of_data:'',
    frequency_Internally:'',
    status:'',
    source:'',
    delivery_method:'',
    delivery_date:'',
    frequency_from_OS:'',
    next_Update:'',
    used_by:'',
    supply_format:''

  }
 constructor(private datasetService : DatasetService, private fb : FormBuilder){

  this.form = this.fb.group({
    DatasetName: ['',[Validators.required]],
    AgeOfData: ['',[Validators.required]],
    Frequency: ['',[Validators.required]],
    status:['',[Validators.required]],
    source:  ['',[Validators.required]],
    delivery_method:['',[Validators.required]],
    delivery_date:['',[Validators.required]],
    frequency_from_OS:['',[Validators.required]],
    next_Update:['',[Validators.required]],
    usedBy: ['',[Validators.required]],
    supplyFormat: ['',[Validators.required]],


  })


 }

 get control() { return this.form.controls; }
  ngOnInit() {

    this.getDatasetsGcomms();

  }
  getDatasetsGcomms() {
    this.datasetService.getDatasetsGcomms()
    .subscribe(
      response => {
        console.log(response );
        this._datasets = response;
        console.log(this._datasets)
      }
    );
  }

  deleteDataset(dataset: DbName)
 {
   //console.log(dataset_id)
   this.datasetService.deleteDataset(dataset)
   .subscribe(
     response => {
      alert(" record deleted successfully");
       this.getDatasetsGcomms();
     },
     err=>{
          alert("something went wrong")
        }
   );
 }

 populateForm(dataset: DbName)
 {
   this.dataset = dataset;
 }
  updateDataset(dataset: DbName) {

    this.datasetService.updateDataset(dataset)
    .subscribe(
      response => {
        alert(" record updated successfully");
        this.getDatasetsGcomms();
      },
      err=>{
        alert("something went wrong")
      }
    );
  }
key: string = 'id';
reverse: boolean = false;
  sort(key: string) {
    this.key = key;
    this.reverse = !this.reverse;
  }

}
