import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'OssApp-Sidebar',
  templateUrl: './Sidebar.component.html',
})
export class SidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
